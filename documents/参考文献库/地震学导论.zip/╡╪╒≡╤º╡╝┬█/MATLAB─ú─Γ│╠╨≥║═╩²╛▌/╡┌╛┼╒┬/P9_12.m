%P9_12.m
load wanprem.txt
r=colormap('jet');
R=6371;
alpha=0:0.01:2*pi;
x=R*cos(alpha);y=R*sin(alpha);
figure(1)
[m,n]=size(wanprem);
Premin=min(wanprem(:,6));Premax=max(wanprem(:,6));
max_min=Premax-Premin;
hold on
for ii=1:m
    Indx=round((wanprem(ii,6)-Premin)/max_min*64);if(Indx==0) Indx=1;end
    fill((R-wanprem(ii,1))*cos(alpha),(R-wanprem(ii,1))*sin(alpha),r(Indx,:),'EdgeColor',r(Indx,:))
end
plot(x,y,'k');
axis equal
axis off
caxis([Premin,Premax]);
H=colorbar;
set(H,'YTick',linspace(Premin,Premax,6),'YtickLabel',num2str(linspace(Premin,Premax,6)'))
annotation('textbox',[0.816,0.824,0.5,0.1],'linestyle','none','String','Q\mu') 
figure(2)
Premax=max(wanprem(:,5));Premin=min(wanprem(:,5));
max_min=Premax-Premin;
hold on
for ii=1:m
    Indx=round((wanprem(ii,5)-Premin)/max_min*64);if(Indx==0) Indx=1;end
    fill((R-wanprem(ii,1))*cos(alpha),(R-wanprem(ii,1))*sin(alpha),r(Indx,:),'EdgeColor',r(Indx,:))
end
plot(x,y,'k');
axis equal
axis off
caxis([Premin,Premax]);
H=colorbar;
set(H,'YTick',linspace(Premin,Premax,6),'YtickLabel',num2str(linspace(Premin,Premax,6)'))
annotation('textbox',[0.816,0.824,0.5,0.1],'linestyle','none','String','Qk') 
