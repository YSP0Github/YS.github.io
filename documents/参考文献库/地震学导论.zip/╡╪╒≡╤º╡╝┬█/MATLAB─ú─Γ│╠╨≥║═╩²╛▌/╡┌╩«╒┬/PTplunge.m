function Tpl=PTplunge(Ptr,Ppl,Ttr) 
Tpl=-atand((cosd(Ptr)*cosd(Ppl)*cosd(Ttr)+sind(Ptr)*cosd(Ppl)*sind(Ttr))/sind(Ppl))     %��ʽ��10-3-12��
return
