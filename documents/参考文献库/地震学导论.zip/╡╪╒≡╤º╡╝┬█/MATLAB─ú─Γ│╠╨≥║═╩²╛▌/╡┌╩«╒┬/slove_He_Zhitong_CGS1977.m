strend=204-180;sdip=10.5;
strike=21;dip=75;
A=[cosd(strend)*cosd(sdip),sind(strend)*cosd(sdip),sind(sdip)];
N=[-sind(strike)*sind(dip),cosd(strike)*sind(dip),-cosd(dip)];
[str,dip,rak]=an2dsr_wan(-A,N)
[Ptrpl,Ttrpl,Btrpl,str2,dip2,rake2]=dsrin(str,dip,rak)