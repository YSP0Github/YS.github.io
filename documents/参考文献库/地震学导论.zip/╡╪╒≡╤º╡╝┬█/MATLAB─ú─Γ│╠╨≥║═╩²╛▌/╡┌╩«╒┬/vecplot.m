function [arw, vec,xend,yend]=vecplot(coordx, coordy, Vx, Vy, scale,arw_scale)
%
% [arw, vec,xend,yend]=vecplot(coordx, coordy, Vx, Vy, scale,arw_scale)
%
%  example..................................................
%  plot(vec(1:2,:),vec(3:4,:),'r','linewidth',1.2);
%  fill(arw(1:3,:),arw(4:6,:),'r','linewidth',1,'edgecolor','r') 
%
%
num=size(Vx,1);
vec=zeros(4,num);
arw=zeros(6,num);


 xend=coordx+scale*Vx;
 yend=coordy+scale*Vy;
 
 vec(1:2,:)=[coordx'; xend'];
 vec(3:4,:)=[coordy'; yend'];
 
 xend=coordx+scale*Vx;
 yend=coordy+scale*Vy;


 a1=zeros(num,1);
 com=find(Vx~=0);
 comN=find(Vx==0 & Vy<0);
 comP=find(Vx==0 & Vy>0);

a1(com)=atan(Vy(com)./Vx(com))*180/pi;
a1(comN)=-90;
a1(comP)=90;
%comN=find(Vy==0 & Vx<0);
%comP=find(Vy==0 & Vx>0);
%a1(comN)=-360;
%a1(comP)=360;


a2=90-(atan(2/0.6)*180/pi);
alp=a1-a2;
bet=a1+a2;

arrowx1=zeros(num,1);
arrowx2=arrowx1;
arrowy1=arrowx1;
arrowy2=arrowx1;

l=arw_scale.*scale*sqrt(2^2+0.6.^2);

if length(arw_scale)==1;


   com1=find(Vx>=0);
   arrowx1(com1)=xend(com1)-l*cos(alp(com1)*pi/180.);
   arrowx2(com1)=xend(com1)-l*cos(bet(com1)*pi/180.);
   arrowy1(com1)=yend(com1)-l*sin(alp(com1)*pi/180.);
   arrowy2(com1)=yend(com1)-l*sin(bet(com1)*pi/180.);

   com2=find(Vx<0); 
   arrowx1(com2)=xend(com2)+l*cos(alp(com2)*pi/180.);
   arrowx2(com2)=xend(com2)+l*cos(bet(com2)*pi/180.);
   arrowy1(com2)=yend(com2)+l*sin(alp(com2)*pi/180.);
   arrowy2(com2)=yend(com2)+l*sin(bet(com2)*pi/180.); 
   
else
        

   com1=find(Vx>=0);
   arrowx1(com1)=xend(com1)-l(com1).*cos(alp(com1)*pi/180.);
   arrowx2(com1)=xend(com1)-l(com1).*cos(bet(com1)*pi/180.);
   arrowy1(com1)=yend(com1)-l(com1).*sin(alp(com1)*pi/180.);
   arrowy2(com1)=yend(com1)-l(com1).*sin(bet(com1)*pi/180.);

   com2=find(Vx<0); 
   arrowx1(com2)=xend(com2)+l(com2).*cos(alp(com2)*pi/180.);
   arrowx2(com2)=xend(com2)+l(com2).*cos(bet(com2)*pi/180.);
   arrowy1(com2)=yend(com2)+l(com2).*sin(alp(com2)*pi/180.);
   arrowy2(com2)=yend(com2)+l(com2).*sin(bet(com2)*pi/180.); 

    
    
end

   
   
arw(1:3,:)=[xend';arrowx1';arrowx2'];
arw(4:6,:)=[yend';arrowy1';arrowy2'];


 
  